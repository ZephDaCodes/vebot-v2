let config = {
  prefix: ","
}

module.exports = config;

