const Discord = require("discord.js")
module.exports = {
  name: 'rules',
  description: 'rules',
  execute(client, message, args){
    const img1 = new Discord.MessageEmbed()
      .setColor('#3e93de')
      .setImage('https://imgur.com/jq5GZPY.png');

    const rules1 = new Discord.MessageEmbed()
      .setTitle('Discord Rules')
      .setColor('#3e93de')
      .setDescription('These are the Vanilla Earth Discord rules. Failing to comply will result in punishments without warning.')
      .addFields(
        {name: '1) Resepct Everyone', value: 'No toxicity, racism, sexism, homophobia, insulting or harassing others. Anything that is deemed offensive by the players or staff team will be punishable.'},
        {name: '2) No Advertising', value: `Advertising includes but is not limited to: posting a server's IP, posting non-VE servers, DMing people invites to your server, or asking people if they want to join a server.` },
        {name: '3) Apporiate Channels', value: `Keep your messages related to the channel's intended purposes. For example, keeping bot commands to a minimum in <#838173703291273216>.`},
        {name: '4) Inapporiate Content', value: 'Do not post inapporiate content. This includes but is not limited to NSFW imageries, poronography, gore, and deceased animals/people.'},
        {name: '5) Raiding Servers', value: 'Raiding other Discord servers is not allowed. You will be banned indefinitely without hesitation.'},
        {name: '6) Alts', value: 'No alternate accounts in this Discord server.'},
        {name: '7) Spamming', value: 'No spamming allowed. This means no sending messages over and over in a short period of time.'},
        {name: '8) Finding Loopholes', value: 'Don’t try to bypass our rules or find loopholes. You can be punished for things that are not included in our rules. If you are unsure about something, you can always ask a staff member.'}
      )
      .setFooter('Vanilla Earth | Discord Rules');

    const rules2 = new Discord.MessageEmbed()
      .setTitle('Minecraft Rules')
      .setColor('#3e93de')
      .setDescription('These are the Vanilla Earth Discord rules. Failing to comply will result in punishments without warning.')
      .addFields(
        {name: '1) Unfair Advantages', value: 'No hacking, glitching, using baritone, macros, duping, xray, or anything that gives you an unfair advantage.'},
        {name: '2) Spamming', value: 'No spamming allowed. This means no sending messages over and over in a short period of time.'},
        {name: '3) No advertising', value: `Advertising includes but is not limited to: posting a server's IP, posting Discord invites, or asking people if they want to join a server.`},
        {name: '4) Respect Everyone', value: 'No toxicity, racism, sexism, homophobia, insulting or harassing others. Anything that is deemed offensive by the players or staff team will be punishable.'},
        {name: '5) No AFK Farms', value: 'AFK Farms includes but is not limited to: automatic farms, and farms that work while you are AFK.'},
        {name: '6) Griefing, Inappropriate Builds and Names', value: 'No inappropriate builds, large scale greifing of unclaimed land/natural terrain, item names, or town names.'},
        {name: '7) Being an Accomplice', value: 'If you work with cheaters, you will be banned. This includes getting items from cheaters, lying to staff members, distributing duped items, etc.'},
        {name: '8) Trapping Players', value: `Don't kill players using TP traps, bed traps, spawn traps, portal traps, or combat traps. All other traps are allowed as long as they are in a claim.`},
        {name: '9) Disrupting the Server', value: 'Any form of builds/actions done with the intent to break the server will result in a ban. This includes lag machines, duping and distributing said items, raiding, bookbanning, chunkbanning, etc.'},
        {name: '10) Finding Loopholes', value: 'Don’t try to bypass our rules or find loopholes. You can be punished for things that are not included in our rules. If you are unsure about something, you can always ask a staff member.'}
      )
      .setFooter('Vanilla Earth | MC Rules');
    
    const img2 = new Discord.MessageEmbed()
      .setColor('#3e93de')
      .setImage('https://i.imgur.com/2KFJWW2.png');
    
    const partners = new Discord.MessageEmbed()
      .setTitle('Content Creator Requirements')
      .setColor('#3e93de')
      .setDescription('Are you a content creator and want to be verified on our server? If you meet the following requirements, open a ticket in <#759758562422423562> to apply.')
      .addFields(
      {name: '<:youtube:841142714077544449> | YouTube', value: '- 250+ subscribers\n- Steady viewer base\n- Have uploaded Minecraft related videos\n- Active channel\n- At least two VE related video monthly'},
      {name: '<:twitch:841142714363674665> | Twitch', value: '- 250+ followers\n- Steady viewer base\n- Have Minecraft related streams\n- Active schedule\n- At least two VE related stream monthly'}
      )
      .addField('Other Medias', 'If you have other media channels, we will review on a case-to-case basis. Open a ticket if you feel qualified.')
      .setFooter('Vanilla Earth | Content Creator');
    
    const img3 = new Discord.MessageEmbed()
      .setColor('#3e93de')
      .setImage('https://i.imgur.com/Ymw1shC.png');

    const info = new Discord.MessageEmbed()
      .setTitle('Minecraft Server Information')
      .setColor('#3e93de')
      .addField('Java IP', 'vanillaearth.fun')
      .addField('Bedrock IP', 'vanillaearth.fun (port 8103)')
      .addField('Dynmap', 'http://vanillaearth.fun:8103/')
      .setFooter('Vanilla Earth | Server Information')
    
    message.channel.send(img1);
    message.channel.send(rules1);
    message.channel.send(rules2);
    message.channel.send(img2);
    message.channel.send(partners);
    message.channel.send(img3);
    message.channel.send(info);
  }
}