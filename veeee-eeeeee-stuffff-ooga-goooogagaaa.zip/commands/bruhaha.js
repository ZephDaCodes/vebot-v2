const Discord = require('discord.js');

module.exports = {
  execute(client, message, args) {
  const bruh = new Discord.MessageEmbed()
    .setTitle("Reaction Roles")
    .setColor('#3e93de')
    .setDescription("🔔 | Frequent notifications on server updates, events, and giveaways\n\n📷 | Server media pings\n\n❗ | Only Minecraft related pings")
    .setFooter("Vanilla Earth | Reaction Roles");
  message.channel.send(bruh)}};